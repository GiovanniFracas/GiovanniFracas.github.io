/* Creo una scacchiera di 800 x 800 px usando jQuery */
$('<div id="scacchiera"></div>').css({
	'width': '800px',
	'height': '800px',
	'background-color': '#F0F0F0',
	'position': 'absolute',
	'top': '0',
	'left': '0'
}).appendTo('body');
for (var i = 0; i < 8; i++) {
	for (var j = 0; j < 8; j++) {
		$('<div class="casella"></div>').css({
			'width': '100px',
			'height': '100px',
			'background-color': (i + j) % 2 === 0 ? '#F0F0F0' : '#C0C0C0',
			'position': 'absolute',
			'top': (i * 100) + 'px',
			'left': (j * 100) + 'px'
		}).appendTo('#scacchiera');
	}
}

/* Quando il puntatore del mouse entra nella casella, i bordi in alto e a sinistra diventano blu */
$('#scacchiera').on('mouseenter', '.casella', function () {
	$(this).css({
		'border-top': '2px solid blue',
		'border-left': '2px solid blue'
	});
});

/* Quando il puntatore del mouse esce dalla casella, i bordi devono essere rimossi */
$('#scacchiera').on('mouseleave', '.casella', function () {
	$(this).css('border', 'none');
});

/* Quando si clicca su una casella, la casella diventa marrone */
$('#scacchiera').on('click', '.casella', function () {
	$(this).css({
		'background-color': 'brown'
	});
});

/* Se clicchi due volte con il mouse su una casella, la casella diventa nera */
$('#scacchiera').on('dblclick', '.casella', function () {
	$(this).css({
		'background-color': 'black'
	});
});

/* Se clicchi sull'ultima casella in alto a sinistra appare il testo “Epicode” */
$('#scacchiera').on('click', '.casella:first-child', function () {
	$(this).css({
		'background-color': 'black',
		'border-top': '2px solid blue',
		'border-left': '2px solid blue'
	});
	$('<div id="epicode"></div>').css({
		'position': 'absolute',
		'top': '0',
		'left': '0',
		'width': '400px',
		'height': '400px',
		'background-color': '#F0F0F0',
		'color': 'black',
		'font-size': '30px',
		'text-align': 'center',
		'line-height': '400px'
	}).appendTo('body');
	$('#epicode').text('Epicode');
});