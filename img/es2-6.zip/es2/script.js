// quando il documento è pronto...(forma breve)
$(() => {
	// event handler click per il pulsante cambia altezza e larghezza
	$('.js-change-height-width-btn').on('click', function () {
		// animo il container con animate()
		$('.js-height-width-container').animate({
			height: '300px',
			width: '300px',
		});
	});
	// uso .each() per ogni elemento della lista
	$('.js-list li').each(function (index, item) {
		const currentEl = $(this);
		// click per ogni elemento della lista
		currentEl.on('click', function () {
			// tolgo gli elementi li con la classe active e nascondo il figlio con la classe js-accordion-content
			$('.js-list')
				.find('li.active')
				.removeClass('active')
				.children('.js-accordion-content')
				.hide();

			// aggiungo active all'elemento li cliccato e mostro il figlio con la classe js-accordion-content
			currentEl
				.addClass('active')
				.children('.js-accordion-content')
				.slideToggle();
		});
	});

	// aggiungo event handler click per il pulsante Upload file
	$('.js-upload-file-btn').on('click', function () {
		// creo l'animazione della progress bar
		$('#progressBar').animate(
			{
				width: '300px',
			},
			{
				duration: 5000,
				step: function (x) {
					$('.js-progress-step').text(Math.round((x * 100) / 300) + '%');
				},
			}
		);
	});
});
