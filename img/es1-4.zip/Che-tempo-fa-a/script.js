$( () => {
    $('#info-meteo').on('click', function() {
        const ricerca = $('#input-city').val();
        if (!ricerca) {
            $('#error-mes').show();
            return;
        }

        const btn = $(this);
        btn.prop('disabled', true).text('Sto caricando...');

        const chiave = 'd53897e2e484f48e99e912455730692b';

        $.ajax({
            url: `http://api.weatherstack.com/current?access_key=${chiave}&query=${ricerca}`,
            success: function(resp) {
                if(resp.hasOwnProperty('current')) {
                    const HTML = `<p>Temperatura: ${resp.current.temperature}</p>
                                <p>Informazioni meteo: ${resp.current.weather_descriptions.join('')}</p>
                                <p>Umidità: ${resp.current.humidity}</p>
                                <p>Velocità del vento: ${resp.current.wind_speed}</p>
                                <p>Direzione del vento: ${resp.current.wind_dir}</p>
                                <p>Pressione atmosferica: ${resp.current.pressure}</p>
                                <p>Luogo: ${resp.location.name}, ${resp.location.country}</p>`;
                    $('#dati-meteo').html(HTML);
                } else {
                    $('#dati-meteo').html('Nessun dato disponibile');
                }
                btn.prop('disabled', false).text('Che tempo fa?');
            },
            error: function(err) {
                btn.prop('disabled', false).text('Che tempo fa?');
                $('#dati-meteo').html('Nessun dato disponibile');
            }
        });
    });
    $('#input-city').on('focus', function() {
        $('#error-mes').hide();
    });
});