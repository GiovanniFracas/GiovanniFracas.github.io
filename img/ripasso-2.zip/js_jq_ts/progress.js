var avvia = document.getElementById('avvia');

avvia.addEventListener('click', partenza);

function partenza() {
    let progressBar = document.getElementById('progress');
    let larghezza = 1;
    let intervallo = setInterval(cresci, 10);
    function cresci() {
        if (larghezza >500) {
            clearInterval(intervallo);
            location.href = 'pippo.html';
        } else {
            larghezza++;
            progressBar.style.width = larghezza + 'px';
        }
    }
}