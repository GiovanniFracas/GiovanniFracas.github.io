class Utente {
    nome;
    cognome;
    eta;
    constructor (_nome, _cognome, _eta) {
        this.nome = _nome;
        this.cognome = _cognome;
        this.eta = _eta;
    }
    utenteCompleto() {
        return `${this.nome}, ${this.cognome}, ${this.eta}`;
    }
}

class Studente extends Utente {
    corsi = [];

    corsiStudente() {
        return `${this.corsi}`;
    }
}

// class Docente extends Utente {
//     skills = [];
//     constructor(_nome, _cognome, _eta, _skills) {
//         super (_nome, _cognome, _eta)
//         this.skills = _skills;
//     }
// }

class Docente extends Utente {
    skills = [];

    skillsDocente() {
        return `${this.skills}`;
    }
}

$(() => {
    let utente = new Utente('Mario', 'Rossi', 45);
    let studente = new Studente('Nicola', 'Bianchi', 28);
    studente.corsi = ['HTML', 'CSS', 'Javascript'];
    let docente = new Docente('Anna', 'Verdi', 30);
    docente.skills = ['Web development', 'OOP'];

    $('#utente').html('Utente semplice: ' + utente.utenteCompleto());
    $('#studente').html('Studente: ' + studente.utenteCompleto() + ' / Corsi: ' + studente.corsiStudente());
    $('#docente').html('Docente: ' + docente.utenteCompleto() + ' / Skills professionali: ' + docente.skillsDocente());
});