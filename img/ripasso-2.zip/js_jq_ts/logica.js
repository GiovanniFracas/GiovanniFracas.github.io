$(() => {
    // let testo1 = 'ciao ';
    // let testo2 = 'ragazzi';
    // $('#testo').text(testo1 + testo2);
    // let num1 = 3;
    // let num2 = 6;
    // let calcolo = num1 + num2;
    // $('#operazione').text(calcolo);

    init();

    function init() {
        scriviTesto();
        scriviCalcolo();
        esempioReturn();
    }

    function scriviTesto() {
        let testo1 = 'ciao ';
        let testo2 = 'ragazzi';
        $('#testo').text(testo1 + testo2);
    }

    function scriviCalcolo() {
        let num1 = 3;
        let num2 = 6;
        let calcolo = num1 + num2;
        $('#operazione').text(calcolo);
    }

    $('#button').on('click', function () {
        $(this).removeClass('rosso').addClass('blu').text('blu');
    });

    function esempioReturn() {
        let risultato = somma();
        $('#risultato').text(risultato);
    }

    function somma() {
        let valore = 2 + 3;
        return 'Il risultato della somma è: ' + valore;
    }

});