$(() => {
    localStorage.clear();
    $('#entra').on('click', function() {
        let utente = $('#user').val();
        let password = $('#password').val();
        if (utente == '' || password == '') {
            alert('Inserire nome utente e password');
        } else {
            localStorage.setItem('utente', utente);
            location.href = 'benvenuto.html';
        }
    })
});