let array = ['Inter', 'Milan', 'Roma', 'Lazio', 'Napoli', 'Juventus', 'Bologna', 'Atalanta', 'Fiorentina'];

// Jquery con input
// $(() => {
//     $('#filtra').on('click', function () {
//         // Controllo input vuoto
//         if ($('#scegliVoce').val() == '') {
//             $('#voceScelta').html('Inserisci un numero');
//             // Controllo input superiore alle voci dell'array
//         } else if (Number($('#scegliVoce').val()) > (array.length) || $('#scegliVoce').val() == '0') {
//             $('#voceScelta').html('Inserisci un numero tra 1 e ' + (array.length));
//         } else {
//             // scelta a buon fine
//             let numero = (Number($('#scegliVoce').val())) - 1;
//             $('#voceScelta').html('Hai selezionato ' + array[numero]);
//         }
//     });
// });

// Jquery con select
// $(() => {
//     for (i = 0; i < array.length; i++) {
//         $('#scegliVoce').append(`<option value = "${i}">${array[i]}</option>`)
//     }
//     $('#scegliVoce').on('change', function () {
//         let indice = $('#scegliVoce').prop('selectedIndex');
//         $('#voceScelta').html(`Hai selezionato ${array[indice - 1]}`);
//     })
// });

// Vanilla con select
// let combo = document.getElementById('scegliVoce');
// let risposta = document.getElementById('voceScelta');
// window.addEventListener('load', init);
// function init() {
//     for (i = 0; i < array.length; i++) {
//         combo.innerHTML += '<option value = "' + i + '">' + array[i] + '</option>';
//     }
//     combo.addEventListener('change', scelta);
// }
// function scelta() {
//     let indice = combo.selectedIndex;
//     risposta.innerHTML = 'Hai selezionato ' + array[indice - 1];
// }