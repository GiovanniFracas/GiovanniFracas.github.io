/* Trasformare lo script in modo che la somma sia effettuata a partire da due valori immessi in due campi di input */
$(() => {

    $('#calcola').on('click', function () {
        let val1 = $('#val1').val();
        let val2 = $('#val2').val();
        if (val1 == '' || val2 == '') {
            $('#risultato').html('<h2>INSERIRE VALORI NUMERICI</h2>');
            return;
        } else {
            somma(Number(val1), Number(val2));
            $('#val1').val('');
            $('#val2').val('');
        }
    });

    function somma(a, b) {
        $('#risultato').text('Somma: ' + (a + b));
    }

});