class Corsi {
    nome;
    argomento;
    durata;
    constructor(_nome, _argomento, _durata) {
        this.nome = _nome;
        this.argomento = _argomento;
        this.durata = _durata;
    }
    corsoCompleto() {
        return `Corso ${this.nome} su ${this.argomento} della durata di ${this.durata}`;
    }
}

$(() => {
    var corso1 = new Corsi('FE07', 'Front-End Development', '4 mesi');
    var corso2 = new Corsi('BE07', 'Back-End Development', '3 mesi');
    var corso3 = new Corsi('FS07', 'Full Stack Development', '4 mesi');

    $('#corso1').html(corso1.corsoCompleto());
    $('#corso2').html(corso2.corsoCompleto());
    $('#corso3').html(corso3.corsoCompleto());
});