import { Utente } from "./utente.js";

export class Studente extends Utente {
    corsi = [];
    
    corsiStudente() {
        return `${this.corsi}`;
    }
}