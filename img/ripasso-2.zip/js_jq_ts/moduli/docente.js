import { Utente } from "./utente.js";

export class Docente extends Utente {
    skills = [];

    skillsDocente() {
        return `${this.skills}`;
    }
}