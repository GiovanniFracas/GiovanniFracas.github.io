import { Utente } from "./moduli/utente.js";
import { Studente } from "./moduli/studente.js";
import { Docente } from "./moduli/docente.js";

$(() => {
    let utente = new Utente('Mario', 'Rossi', 45);
    let studente = new Studente('Nicola', 'Bianchi', 28);
    studente.corsi = ['PHP', 'MySql', 'Node.js'];
    let docente = new Docente('Giovanna', 'Verdi', 20);
    docente.skills = ['Back-end programming', 'Server-side programming', 'OOP', 'DBA'];

    $('#utente').html(utente.utenteCompleto());
    $('#studente').html(studente.utenteCompleto() + ' / Corsi: ' + studente.corsiStudente());
    $('#docente').html(docente.utenteCompleto() + ' / Skills professionali: ' + docente.skillsDocente());
});