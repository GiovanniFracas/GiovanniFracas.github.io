$(() => {
    let mieiDischi = [];
    mieiDischi = ['Foxtrot', 'Vocalese', 'Tommy', 'Ummagumma'];

    init();

    function init() {
        scriviLista();
    }

    function scriviLista() {
        let lista = '';
        for (i = 0; i < mieiDischi.length; i++) {
            lista += '<li>' + mieiDischi[i] + '</li>'
        }
        $('#dischi').html(lista);
    }

    $('#aggiungi').on('click', function () {
        let newDisco = $('#newDisco').val();
        mieiDischi.push(newDisco);
        scriviLista();
    });
});