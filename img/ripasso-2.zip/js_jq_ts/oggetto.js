$(() => {
    const persona = {
        nome: 'Dario',
        cognome: 'Del Giudice',
        eta: 54,
        email: 'dario@dario.com',
        nomeCompleto: function() {
            return this.nome + ' ' + this.cognome;
        },
        citta: function(nomeCitta) {
            return 'Città: ' + nomeCitta;
        }
    }

    $('#nome').html(persona.nome);
    $('#cognome').html(persona.cognome);
    $('#eta').html(persona.eta);
    $('#email').html(persona.email);
    $('#nomeCompleto').html(persona.nomeCompleto());
    $('#citta').html(persona.citta('Portici (NA)'));

    for (let elementi in persona) {
        $('#oggettoCompleto').append(`${persona[elementi]} `);
    }

    for (let nomi in persona) {
        $('#oggettoNomi').append(`${persona} `);
    }

    function Corso (nome, materia, durata) {
        this._nome = nome;
        this._materia = materia;
        this._durata = durata;
    }

    const fe07 = new Corso('FE07', 'Front-End Development', '4 mesi');

    $('#costruttore1').html(`Corso ${fe07._nome} su ${fe07._materia} della durata di ${fe07._durata}`);

    const be07 = new Corso('BE07', 'Back-End Development', '3 mesi');

    $('#costruttore2').html(`Corso ${be07._nome} su ${be07._materia} della durata di ${be07._durata}`);
});