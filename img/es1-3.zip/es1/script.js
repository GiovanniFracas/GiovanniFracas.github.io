$( () => {
    const carosello = $('#img-l');

    $('#l-btn').click( () => {
        const lProp = parseInt(carosello.css('left'));

        let newLProp = 0;
        if (lProp < 0) {
            newLProp = lProp + 300;
        }

        carosello.animate({left: newLProp}, 1000);
    });

    $('#r-btn').click( () => {
        const lProp = parseInt(carosello.css('left'));

        let newLProp = 0;
        if (lProp - 300 > -1300) {
            console.log(lProp);
            newLProp = lProp - 300;
        }

        carosello.animate({left: newLProp}, 1000);
    });
});